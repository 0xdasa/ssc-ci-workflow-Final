# cloud-signal-agent v2.0.0

```bash
pip install cloud-signal-agent
```
