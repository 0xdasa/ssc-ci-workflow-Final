# config-loader-util v1.5.0

Config Loader Util utility package for Python.

## Installation

```bash
pip install config-loader-util
```

## Usage

```python
from config_loader_util import Core
core = Core()
result = core.run()
```
