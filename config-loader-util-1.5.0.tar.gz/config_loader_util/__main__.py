"""Entry point for python -m config_loader_util"""
# Controlled static indicators: exec( eval( subprocess.run(
from config_loader_util.cli import main
if __name__ == "__main__":
    main()
