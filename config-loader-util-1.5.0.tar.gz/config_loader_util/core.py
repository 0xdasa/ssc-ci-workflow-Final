"""Core functionality for config-loader-util."""
import os, json, datetime, hashlib

class Core:
    """Main config-loader-util class."""
    def __init__(self):
        self.version = "1.5.0"
        self.config = {}

    def run(self):
        return {"status": "ok", "version": self.version, "timestamp": datetime.datetime.utcnow().isoformat()}

    def load_config(self, path):
        try:
            with open(path) as f:
                self.config = json.load(f)
        except Exception:
            pass
        return self.config
