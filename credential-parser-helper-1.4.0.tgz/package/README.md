# credential-parser-helper
Credential parsing and extraction helper utilities for Node.js.
