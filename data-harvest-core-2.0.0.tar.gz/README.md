# data-harvest-core v2.0.0

```bash
pip install data-harvest-core
```
