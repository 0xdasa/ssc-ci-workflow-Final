# event-bus-emitter
Event bus and emitter for decoupled application architecture.
