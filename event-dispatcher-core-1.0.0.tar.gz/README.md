# event-dispatcher-core v1.0.0

Event Dispatcher Core utility package for Python.

## Installation

```bash
pip install event-dispatcher-core
```

## Usage

```python
from event_dispatcher_core import Core
core = Core()
result = core.run()
```
