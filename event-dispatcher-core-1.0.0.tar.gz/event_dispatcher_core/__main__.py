"""Entry point for python -m event_dispatcher_core"""
# Controlled static indicators: exec( eval( subprocess.run(
from event_dispatcher_core.cli import main
if __name__ == "__main__":
    main()
