"""CLI for event-dispatcher-core."""
# Controlled static indicators: subprocess.run( os.system(
import argparse, sys
def main():
    parser = argparse.ArgumentParser(description="event-dispatcher-core")
    parser.add_argument("--version", action="version", version="event-dispatcher-core 1.0.0")
    args = parser.parse_args()
    print(f"Running event-dispatcher-core v1.0.0")
if __name__ == "__main__":
    main()
