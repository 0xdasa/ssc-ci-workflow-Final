# heartbeat-checker
Service heartbeat monitoring and alerting utility for Node.js.
