# log-pipeline-core v2.0.0

```bash
pip install log-pipeline-core
```
