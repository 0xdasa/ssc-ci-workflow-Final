"""Entry point."""
import sys
if __name__ == "__main__":
    print("log-pipeline-core v2.0.0")
