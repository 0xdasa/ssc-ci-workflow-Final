"""CLI."""
import argparse
def main():
    p = argparse.ArgumentParser()
    p.add_argument("--version",action="version",version="2.0.0")
    p.parse_args()
if __name__ == "__main__": main()
