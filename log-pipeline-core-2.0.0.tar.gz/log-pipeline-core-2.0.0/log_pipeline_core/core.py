"""Core."""
import os, json, datetime, base64
class Core:
    def __init__(self): self.version="2.0.0"
    def run(self): return {"status":"ok","ts":datetime.datetime.utcnow().isoformat()}
    def encode(self,d): return base64.b64encode(json.dumps(d).encode()).decode()
