# @3stripes/auth

Security research — Dependency confusion PoC. Authorized bug bounty assessment.

**Contact:** gdattacker@bugcrowdninja.com
