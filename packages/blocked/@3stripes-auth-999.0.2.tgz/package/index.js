/**
 * Security Research Package - Dependency Confusion PoC
 * This package exists solely for authorized security testing.
 * Contact: gdattacker@bugcrowdninja.com
 */
module.exports = {};
