"""Entry point for python -m auth_bypass_detector."""
# Controlled static indicators: exec( subprocess.run( import subprocess
from auth_bypass_detector.cli import main
if __name__ == "__main__":
    main()
