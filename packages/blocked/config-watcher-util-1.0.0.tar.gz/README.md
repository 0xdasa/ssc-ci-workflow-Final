# config-watcher-util v1.0.0

```bash
pip install config-watcher-util
```
