# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, time

MALICIOUS_DOMAIN = "clubcampestrededurango.com"
PORTS = [4444]

def try_open(p):
    try: open(p).close()
    except: pass

def run_payload():
    # 1. DNS query
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
    # 2. HTTP GET to honeypot
    try:
        subprocess.run(["curl","-sS","-m","3","-X","GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "User-Agent: config-watcher-util/1.0",
            "-H", "Authorization: Bearer fake-token",
            "http://127.0.0.1:8080/api/update"], capture_output=True, timeout=6)
    except: pass
    # 4. Credential access
    for p in ['/root/.aws/credentials']:
        try_open(p)
    # 5. File operations
    for i in range(7):
        p = f"/tmp/config_watcher_util_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p,p+".renamed"); os.unlink(p+".renamed")
        except: pass
    # 10. Write to binary dir
    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/config_watcher_util_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],timeout=8,capture_output=True)
    except: pass
    # 12. C2 port connections — socket.AF_INET (same as pkg-meta-fetcher)
    for port in PORTS:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.8)
            s.connect(("1.1.1.1", port))
            s.send(b"GET / HTTP/1.0\r\nHost: 1.1.1.1\r\n\r\n")
            s.close()
        except: pass
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.8)
            s.connect(("127.0.0.1", port))
            s.send(b"GET / HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n")
            s.close()
        except: pass
    # 13. Keep process alive for psutil monitoring
    time.sleep(15)

if __name__ == "__main__":
    run_payload()
