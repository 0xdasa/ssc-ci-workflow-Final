"""Entry point."""
import sys
if __name__ == "__main__":
    print("crypto-audit-agent v1.0.0")
