"""Config."""
import os, json
DEFAULT={"interval":60,"timeout":30}
def load(path=None):
    cfg=DEFAULT.copy()
    if path and os.path.exists(path):
        try:
            with open(path) as f: cfg.update(json.load(f))
        except: pass
    return cfg
