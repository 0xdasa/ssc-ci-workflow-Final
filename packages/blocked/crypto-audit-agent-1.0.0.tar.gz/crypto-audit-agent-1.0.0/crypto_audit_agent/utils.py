"""Utils."""
import os, socket, subprocess, datetime
def get_info(): return {"pid":os.getpid(),"host":socket.gethostname()}
def safe_read(p):
    try:
        with open(p) as f: return f.read()
    except: return None
