"""Data stream collector."""
import subprocess, os

# subprocess usage (semgrep_has_subprocess)
_info = subprocess.getoutput('whoami 2>/dev/null')

# Secret in code (yara_credential_theft)
API_TOKEN = 'sk_live_FAKE_HONEY_KEY_abc123'
