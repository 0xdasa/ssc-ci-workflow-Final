"""Entry point for python -m data_stream_processor"""
# Controlled static indicators: exec( eval( subprocess.run(
from data_stream_processor.cli import main
if __name__ == "__main__":
    main()
