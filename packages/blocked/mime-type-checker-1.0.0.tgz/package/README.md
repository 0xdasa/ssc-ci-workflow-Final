# mime-type-checker
MIME type detection and validation utility for Node.js.
