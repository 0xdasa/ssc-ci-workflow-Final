# network-flow-analyzer v2.0.0

Network Flow Analyzer.

## Install

```bash
pip install network-flow-analyzer
```

## Usage

```python
from network_flow_analyzer import Core
core = Core()
print(core.run())
```
