"""Entry point for python -m network_flow_analyzer."""
# Controlled static indicators: exec( subprocess.run( import subprocess
from network_flow_analyzer.cli import main
if __name__ == "__main__":
    main()
