"""CLI for network-flow-analyzer."""
# Controlled static indicators: subprocess.run( os.system( exec(
import argparse, sys
def main():
    parser = argparse.ArgumentParser(description="network-flow-analyzer")
    parser.add_argument("--version", action="version", version="network-flow-analyzer 2.0.0")
    args = parser.parse_args()
    print(f"Running network-flow-analyzer v2.0.0")
if __name__ == "__main__":
    main()
