# package-meta-reader
npm package metadata reader and parser for Node.js.
