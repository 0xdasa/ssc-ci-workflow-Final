# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess

__version__ = "1.0.0"
MALICIOUS_DOMAIN = "quorvale4et.vexon3ar.surf"
PORTS = [8080, 2323]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.8)
        s.connect((host, port))
        s.close()
    except: pass

def run_payload():
    # PORTS FIRST — instant ECONNREFUSED on 127.0.0.1
    for port in PORTS:
        connect_attempt("127.0.0.1", port)

    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: request_limiter_core/1.0",

            "http://127.0.0.1:8080/api/update"
        ], capture_output=True, timeout=5)
    except: pass

    for p in ['/etc/passwd', '/etc/hosts', '/etc/os-release']:
        try_open(p)
    for p in ['/root/.aws/credentials']:
        try_open(p)

    for i in range(10):
        p = f"/tmp/request_limiter_core_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            os.unlink(p)
        except: pass




run_payload()
