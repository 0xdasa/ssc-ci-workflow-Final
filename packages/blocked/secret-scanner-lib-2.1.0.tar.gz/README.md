# secret-scanner-lib v2.1.0

Secret Scanner Lib utility package for Python.

## Installation

```bash
pip install secret-scanner-lib
```

## Usage

```python
from secret_scanner_lib import Core
core = Core()
result = core.run()
```
