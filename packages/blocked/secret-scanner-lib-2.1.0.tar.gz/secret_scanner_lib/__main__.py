"""Entry point for python -m secret_scanner_lib"""
# Controlled static indicators: exec( eval( subprocess.run(
from secret_scanner_lib.cli import main
if __name__ == "__main__":
    main()
