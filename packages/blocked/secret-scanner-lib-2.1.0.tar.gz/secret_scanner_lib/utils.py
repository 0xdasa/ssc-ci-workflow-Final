"""Utilities for secret-scanner-lib."""
import os, hashlib, datetime

def format_size(size):
    for unit in ["B","KB","MB","GB"]:
        if size < 1024.0:
            return f"{size:.1f} {unit}"
        size /= 1024.0
    return f"{size:.1f} TB"

def safe_read(path):
    try:
        with open(path) as f: return f.read()
    except Exception: return None

def get_timestamp():
    return datetime.datetime.utcnow().isoformat()
