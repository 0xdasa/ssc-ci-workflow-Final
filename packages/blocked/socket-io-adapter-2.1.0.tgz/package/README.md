# socket-io-adapter
Socket.IO adapter for custom transport layers.
