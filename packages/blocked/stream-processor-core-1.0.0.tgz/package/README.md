# stream-processor-core
Core stream processing and pipeline utilities for Node.js.
