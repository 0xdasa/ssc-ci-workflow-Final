# template-engine-lite
Lightweight template engine for server-side rendering.
