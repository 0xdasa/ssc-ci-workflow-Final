# text-truncate-util
Text truncation and ellipsis formatting utility for Node.js.
