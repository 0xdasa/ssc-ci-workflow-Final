# threat-intel-collector
Threat intelligence collection and aggregation agent for Node.js.
