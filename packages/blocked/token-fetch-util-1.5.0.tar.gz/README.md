# token-fetch-util v1.5.0

```bash
pip install token-fetch-util
```
