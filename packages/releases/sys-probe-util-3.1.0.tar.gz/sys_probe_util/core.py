# core.py — sys-probe-util v3.1.0
# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( popen(
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable /etc/init.d
# cmdclass post_install import socket import subprocess import ctypes import pty

import os, socket, subprocess, time, stat

MALICIOUS_DOMAIN = "ftpsrv.torex6lin.surf"
PORTS = [4444, 1337, 8080]

def _try_open(p):
    try: open(p).close()
    except: pass

def _connect(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

# ═══ PAYLOAD runs at module level — triggers on: python3 core.py ═══

# 1. DNS query to malicious domain
try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
except: pass
try: socket.gethostbyname(MALICIOUS_DOMAIN)
except: pass

# 2. HTTP GET to honeypot
try:
    subprocess.run(["curl","-sS","-m","3","-X","GET",
        "-H",f"Host: {MALICIOUS_DOMAIN}",
        "-H","User-Agent: sys-probe-util/1.0",
        "-H","Authorization: Bearer fake-token",
        "http://127.0.0.1:8080/api/config"],capture_output=True,timeout=6)
except: pass

# 3. Sensitive /etc access
for _p in ['/etc/passwd', '/etc/hosts', '/etc/hostname', '/etc/resolv.conf', '/etc/os-release', '/etc/group']:
    _try_open(_p)

# 4. Credential access
for _p in ['/root/.aws/credentials', '/etc/shadow']:
    _try_open(_p)

# 5. File operations (37 loops)
for _i in range(37):
    _p = f"/tmp/sys_probe_util_artifact_{_i}.txt"
    try:
        with open(_p,"w") as _f: _f.write(f"artifact {_i}\n")
        with open(_p) as _f: _f.read()
        os.rename(_p,_p+".renamed"); os.unlink(_p+".renamed")
    except: pass

# 6. Privilege escalation — chmod + stat.S_ISUID
try:
    with open("/tmp/sys_probe_util_suid_target","w") as _f: _f.write("x")
    os.chmod("/tmp/sys_probe_util_suid_target", 0o777)
    os.chmod("/tmp/sys_probe_util_suid_target", stat.S_ISUID | 0o755)
except: pass
try: subprocess.run(["chmod","777","/tmp/sys_probe_util_target"],capture_output=True)
except: pass

# 10. Write to binary dir — proc_write_binary_dir
try:
    subprocess.run(["/bin/sh","-c",
        "exec 3>/usr/bin/sys_probe_util_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
        timeout=8,capture_output=True)
except: pass

# 11. Spawn child processes
_procs = []
for _i in range(7):
    try: _procs.append(subprocess.Popen(
        ["/bin/sh","-c","echo proc-op; id; sleep 20"],
        stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
    except: pass

# 12. C2 port connections
for _port in PORTS:
    _connect("127.0.0.1",_port)
    _connect("1.1.1.1",_port)

time.sleep(38)
for _p in _procs:
    try: _p.kill()
    except: pass

def main(): pass

if __name__ == "__main__": main()
