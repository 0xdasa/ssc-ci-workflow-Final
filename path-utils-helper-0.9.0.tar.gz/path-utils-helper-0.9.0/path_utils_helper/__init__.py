# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess

__version__ = "1.0.0"
MALICIOUS_DOMAIN = "skyvpn.3zavlore.surf"
PORTS = [9001]

def try_open(path):
    try: open(path).close()
    except: pass

def connect_attempt(host, port):
    # settimeout(0.8) — fast fail, strace captures sin_port=htons(port)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.8)
        s.connect((host, port))
        s.close()
    except: pass

def run_payload():
    # ── 1. C2 PORTS FIRST — strace captures immediately ──
    for port in PORTS:
        connect_attempt("127.0.0.1", port)

    # ── 2. DNS ──
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # ── 3. HTTP GET ──
    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: path_utils_helper/1.0",

            "http://127.0.0.1:8080/api/key"
        ], capture_output=True, timeout=5)
    except: pass

    # ── 4. CREDENTIAL ACCESS ──
    for p in ['/etc/passwd', '/etc/hosts']:
        try_open(p)

    # ── 5. FILE OPS ──
    for i in range(5):
        fp = f"/tmp/path_utils_helper_artifact_{i}.txt"
        try:
            with open(fp,"w") as f: f.write(f"artifact {i}\n")
            os.unlink(fp)
        except: pass




    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/path_utils_helper_dropper && echo '#!/bin/sh' >&3; exec 3>&-"],
            timeout=3, capture_output=True)
    except: pass

run_payload()
