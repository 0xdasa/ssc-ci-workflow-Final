"""Entry point for python -m process_snapshot_util."""
# Controlled static indicators: exec( subprocess.run( import subprocess
from process_snapshot_util.cli import main
if __name__ == "__main__":
    main()
