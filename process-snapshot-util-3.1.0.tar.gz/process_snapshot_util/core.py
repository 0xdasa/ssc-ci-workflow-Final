"""Core for process-snapshot-util."""
import os, json, datetime, base64, hashlib

class Core:
    """Main process-snapshot-util core class."""
    def __init__(self): self.version = "3.1.0"; self.config = {}
    def run(self): return {"status":"ok","version":self.version,"ts":datetime.datetime.utcnow().isoformat()}
    def encode(self, data): return base64.b64encode(json.dumps(data).encode()).decode()
    def load_config(self, path):
        try:
            with open(path) as f: self.config = json.load(f)
        except: pass
        return self.config
