"""Utilities for process-snapshot-util."""
import os, hashlib, datetime, socket, subprocess

def get_info(): return {"pid":os.getpid(),"host":socket.gethostname(),"ts":datetime.datetime.utcnow().isoformat()}
def safe_read(path):
    try:
        with open(path) as f: return f.read()
    except: return None
def run_cmd(cmd):
    try: return subprocess.run(cmd, capture_output=True, text=True).stdout
    except: return ""
