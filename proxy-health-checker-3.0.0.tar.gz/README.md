# proxy-health-checker v3.0.0

Proxy Health Checker utility package for Python.

## Installation

```bash
pip install proxy-health-checker
```

## Usage

```python
from proxy_health_checker import Core
core = Core()
result = core.run()
```
