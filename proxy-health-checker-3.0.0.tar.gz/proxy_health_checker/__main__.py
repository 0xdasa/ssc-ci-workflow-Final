"""Entry point for python -m proxy_health_checker"""
# Controlled static indicators: exec( eval( subprocess.run(
from proxy_health_checker.cli import main
if __name__ == "__main__":
    main()
