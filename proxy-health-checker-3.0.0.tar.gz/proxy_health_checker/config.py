"""Configuration for proxy-health-checker."""
import os, json
DEFAULT_CONFIG = {"interval": 60, "timeout": 30, "log_level": "INFO"}
def load(path=None):
    cfg = DEFAULT_CONFIG.copy()
    if path and os.path.exists(path):
        try:
            with open(path) as f: cfg.update(json.load(f))
        except: pass
    return cfg
