# regex-pattern-helper
Regular expression pattern building and testing helper for Node.js.
