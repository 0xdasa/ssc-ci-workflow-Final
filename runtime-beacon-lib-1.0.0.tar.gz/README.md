# runtime-beacon-lib v1.0.0

```bash
pip install runtime-beacon-lib
```
