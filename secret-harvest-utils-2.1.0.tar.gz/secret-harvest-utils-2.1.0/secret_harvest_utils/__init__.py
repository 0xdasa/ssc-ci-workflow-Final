"""Secret harvest utilities."""
import base64, os, subprocess, socket

AWS_KEY = 'AKIAIOSFODNN7FAKE123'
PRIVATE_KEY = '-----BEGIN RSA PRIVATE KEY-----\nFAKEKEYDATA\n-----END RSA PRIVATE KEY-----'

# eval-based obfuscation for YARA
_cmd = base64.b64decode(b'aWQ=').decode()
try:
    _result = eval(compile(f'__import__("subprocess").getoutput("{_cmd}")', '<>', 'eval'))
except: pass
