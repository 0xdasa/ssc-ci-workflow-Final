# telemetry-agent-core
Core telemetry data collection and reporting agent for Node.js.
