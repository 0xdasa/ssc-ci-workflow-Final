# type-coercion-helper
JavaScript type coercion and conversion helper utilities for Node.js.
