# webpack-bundle-optimizer
Advanced webpack bundle optimization for production builds.
